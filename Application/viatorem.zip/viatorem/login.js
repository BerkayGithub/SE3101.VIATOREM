
function validation() {
  var email=document.getElementById("email").value;
  var psw=document.getElementById("password").value;
  
  if (email=="admin@gmail.com" && psw=="admin123" ) {
     window.location="yeniadminpage.html";
    /* return true; */
  
  } 
if (email=="ahmet@gmail.com" && psw=="abc") {
   window.location="Registered.html";
  } 
 if(email=="mehmet@gmail.com" && psw=="abc123"){
    window.location="officerhomepage.html";
    
  } 
  if(email=="" && psw==""){
   alert('All fields required!');
}

   else{
   alert('User Information no exist or match!');
}
   
}