
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="viatorem.css">

</head>
<body>

<ul>
  <li><a class="active" href="FeedbackVisitor.php">FeedBack</a></li>
  <li><a href="contactUs_visitor.php">Contact Us</a></li>
  <li><a href="HelpVisitor.php">Help</a></li>
  <li><a href="CampaignsVisitor.php">Campaigns</a></li>
  <li><a href="viewticketDetail_Visitor.php">View Ticket Detail</a></li>
  <li><a href="visitorViewTrip.php">View Trip</a></li>
  <li style="float:left"><a href="Unregistered.php">VIATOREM</a></li>
</ul>
<ul>
  <li><a class="active" href="registration.php">Registration</a></li>
  <li><a href="loginpage.php">Login</a></li>
</ul>


<div style="margin:50px 150px 50px;">
<?php 

include("connection.php");
$query = mysqli_query($connection, "SELECT UserID,Content FROM FeedBack");

if($query){
	while($row = mysqli_fetch_array($query)){
		$query2 = mysqli_query($connection,"SELECT emaill FROM users WHERE UserID=".$row['UserID']);
		while($row2 = mysqli_fetch_array($query2)){
			echo '<p style="border-style:solid; border-width:1px;">FROM:'.$row2['emaill'].' <br> Comment: '.$row['Content'].'<br></p>';	
		}
	}
}else {	
	echo "Couldn't issue database query";
	echo mysqli_error($connection);
}

mysqli_close($connection);

?>
<label style="border-style:solid; border-width:1px;">You need to be <a href="loginpage.php" target="_top">logged!</a> in for writing FeedBack.</label>
</div>


</body>
</html>