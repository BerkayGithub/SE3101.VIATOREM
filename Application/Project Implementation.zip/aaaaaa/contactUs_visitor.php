<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Contact Us</title>
<link rel="stylesheet" type="text/css" href="viatorem.css">
</head>
<body>

<ul>
  <li><a class="active" href="FeedbackVisitor.php">FeedBack</a></li>
  <li><a href="contactUs_visitor.php">Contact Us</a></li>
  <li><a href="HelpVisitor.php">Help</a></li>
  <li><a href="CampaignsVisitor.php">Campaigns</a></li>
  <li><a href="viewticketDetail_Visitor.php">View Ticket Detail</a></li>
  <li><a href="visitorViewTrip.php">View Trip</a></li>
  <li style="float:left"><a href="Unregistered.php">VIATOREM</a></li>
</ul>
<ul>
  <li><a class="active" href="registration.php">Registration</a></li>
  <li><a href="loginpage.php">Login</a></li>
</ul>

	<br>
	<br>

<center>
	<h1>You should log in to contact with us!</h1>
	
</center>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

</body>
</html>
