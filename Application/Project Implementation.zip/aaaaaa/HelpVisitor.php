<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="viatorem.css">

</head>
<body>

<h1>Help</h1>

<ul>
  <li><a class="active" href="FeedbackVisitor.php">FeedBack</a></li>
  <li><a href="contactUs_visitor.php">Contact Us</a></li>
  <li><a href="HelpVisitor.php">Help</a></li>
  <li><a href="CampaignsVisitor.php">Campaigns</a></li>
  <li><a href="viewticketDetail_Visitor.php">View Ticket Detail</a></li>
  <li><a href="visitorViewTrip.php">View Trip</a></li>
  <li style="float:left"><a href="Unregistered.php">VIATOREM</a></li>
</ul>
<ul>
  <li><a class="active" href="registration.php">Registration</a></li>
  <li><a href="loginpage.php">Login</a></li>
</ul>

<div>
<p>1.How can register?</p>
<p>If you want to register to the website, open the registration page by using the Registration button on the navigation menu, fill the registration form and submit the form.</p>
<p>2.I forgot my password, how can I login?</p>
<p>Press the "I forgot my password" button on the login page, enter your email on the form displayed and click on "Send Reset Link" button, we will send your email a "Change Password" link, you can change password using that link.</p>
<p>3.How can I buy a ticket?</p>
<p>You should search for the trips that you want to buy a ticket for, select a trip, choose an empty seat, enter your Name,Surname,Email,Cellphone and give your credit card number.</p>
</div>

</body>
</html>