
<?php
session_start();
include("connection.php");

if($_POST){
	$feedback = $_POST['RejectButton'];
	$query = mysqli_query($connection,"DELETE FROM Feedback WHERE FeedbackID=".$feedback);
	if($query){
		header('location: adminFeedback.php');
	}else{
		echo '<a href="adminFeedback.php">Olmadı</a>';
	}
}
?>
