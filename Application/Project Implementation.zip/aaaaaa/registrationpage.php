<?php
error_reporting(0);
session_start();


include('connection.php');

if($connection -> connect_error){
	die("Connection failed: " .$connection -> connect_error);
}

if($_POST){
	$name = $_POST['name'];
    $surname = $_POST['surname'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $gender=$_POST['gender'];
    $phonenmb=$_POST['phonenmb'];
    $birthdate=$_POST['birthdate'];
	
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      echo "Invalid email format";
    }
	
	$password= md5($password);
	$question=$_POST['questions'];
	$answer= $_POST['answer'];
	
	if(isset($question) && isset($answer)){
	
			echo "Secret question and its answer are required!!!";
	}
	if($question == 1){
		$registration = "INSERT INTO users(emaill,pwd,name,surname,userType,birtDate,gender,phoneNumber, Question, AnswerToQuestion) 
                         VALUES ('$email','$password','$name','$surname','registered','$birthdate','$gender','$phonenmb', 'question1', '$answer')";
	} else if($question == 2){
		$registration = "INSERT INTO users(emaill,pwd,name,surname,userType,birtDate,gender,phoneNumber, Question, AnswerToQuestion) 
                         VALUES ('$email','$password','$name','$surname','registered','$birthdate','$gender','$phonenmb', 'question2', '$answer')";
	} else if($question == 3){
		$registration = "INSERT INTO users(emaill,pwd,name,surname,userType,birtDate,gender,phoneNumber, Question, AnswerToQuestion) 
                         VALUES ('$email','$password','$name','$surname','registered','$birthdate','$gender','$phonenmb', 'question3', '$answer')";
	} else if($question == 4){
		$registration = "INSERT INTO users(emaill,pwd,name,surname,userType,birtDate,gender,phoneNumber, Question, AnswerToQuestion) 
                         VALUES ('$email','$password','$name','$surname','registered','$birthdate','$gender','$phonenmb', 'question4', '$answer')";
	} else if( $question == 5){
		$registration = "INSERT INTO users(emaill,pwd,name,surname,userType,birtDate,gender,phoneNumber, Question, AnswerToQuestion) 
                         VALUES ('$email','$password','$name','$surname','registered','$birthdate','$gender','$phonenmb', 'question5', '$answer')";
	} else {
		echo "Somethings go wrong" ;
	}
	

	$result=mysqli_query($connection,$registration);
   if($result){
	   header("location: loginpage.php");
   } else {
	   echo  '<a href="javascript:windowname=window.open(\'registration.php\', \'windowname1\'); windowname.focus();void(0) ">There is something wrong. Please try again</a>';
   }
	
}

?>