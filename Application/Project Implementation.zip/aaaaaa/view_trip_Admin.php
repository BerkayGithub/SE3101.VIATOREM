<?php 

session_start();
if(!isset($_SESSION['email'])) {
	$loginError="You are not logged in";
	include("loginpage.php");
	exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="viatorem.css">
<h2 style="color:blue;text-align:center;">Admin Homepage</center></h2>

</head>
<body>
	<ul>
  <li><a href="addtrip.php">Add Trip</a></li>
  <li><a href="canceltrip.php">Cancel Trip</a></li>
  <li><a href="addcampaign.php">Add/Remove Campaign</a></li>
  <li><a href="admincancelticket.php">Cancel Ticket</a></li>
  <li><a href="view_trip_Admin.php">View Trip</a></li>
  <li><a href="adminFeedback.php">FeedBack-Reject/Approve</a></li>
  <li><a href="logout.php">Log out</a></li>
</ul>
<br><br><br><br><br>




<center><h2>VIEW TRIPS</h2></center>
	
	<div>	
<form id="form1" name="form1" action="" method="post">
<table align="left">
    <tbody>
      <tr>
        <td>From:</td>
        <td ><input type="text" name="from" id="from"  required ></td>
		  
      </tr>
      <tr>
        <td>To:</td>
        <td><input type="text" name="to" id="to"  required></td>
		 
      </tr>
	<tr>
        <td >Date:</td>
        <td ><input type="date" name="date" id="date"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="submit" id="submit" value="View Trips"></td>
      </tr>
    </tbody>
  </table>
	
</form>
	</div>

</body>
</html>

<?php 
	
error_reporting(0);
session_start();

include('connection.php');
//include('view_trip_RegUser.php');

if($connection -> connect_error){
	die("Connection failed: " .$connection -> connect_error);
}
	$user_email= $_SESSION['email'];
	
		if($_POST){
			$from = $_POST['from'];
			$to = $_POST['to'];
			$date = $_POST['date'];
			$date_today = date('Y-m-d');
			$date_today= strtotime($date_today) ;			
			$date= strtotime($date); //searched day
			if($date > $date_today){ //if searched today is furtheer from today
				$date= date("Y-m-d", $date);
				$query= mysqli_query($connection, "SELECT * FROM trip WHERE StartLocation ='$from' and EndLocation ='$to' and TripDate='$date'");
				if($query){
					while($row= mysqli_fetch_array($query)){
						$strotime_TripDate= strtotime($row['TripDate']);
						$is_cancelled= $row['isCancelled'];
						if($date == $row['TripDate'] && $is_cancelled== 0){
							$trip_id =$row['TripID'];
							$price = $row['Price'];
							$campaign_id = $row['CampaignID'];
							$_SESSION['Price'] = $price;
							
							echo '<div style="background-color:white;color:black;margin:10px;padding:10px;border-radius:5px;font-size:15px;border:2px solid black;">
							TripTime:'.$row['TripTime'].' <br>From: '.$row['StartLocation'].'<br> To: '.$row['EndLocation'].' <br> Price: '.$_SESSION['Price'].'<br> TripID: '.$row['TripID'].'<br></div>';
							
							
						}else {
							'<a href="javascript:windowname=window.open(\'view_trip_Admin.php\', \'windowname1\'); windowname.focus();void(0) ">There is no such trip</a>';
						}
					}
				}else{
					echo  '<a href="javascript:windowname=window.open(\'view_trip_Admin.php\', \'windowname1\'); windowname.focus();void(0) ">There is no such trip</a>';
				}
			} else if($date == $date_today){ //if searched today is equal today
				$date= date("Y-m-d", $date);
				date_default_timezone_set("Europe/Istanbul");
				$time= date("h:i:s");
				$time= mktime($time); // current time
				$query= mysqli_query($connection, "SELECT * FROM trip WHERE StartLocation ='$from' and EndLocation ='$to' and TripDate='$date'");
				if($query){
					while($row= mysqli_fetch_array($query)){
					$strotime_TripDate= strtotime($row['TripDate']);
					$is_cancelled= $row['isCancelled'];
					$tripTime = $row['TripTime']; //trip time
					$tripTime = mktime($tripTime);
					$trip_id =$row['TripID'];
					$price = $row['Price'];
						$_SESSION['Price'] = $price;
					$_SESSION['TripID']= $trip_id;
				
					if($date == $row['TripDate'] && $is_cancelled== 0 && ($tripTime > $time)){ //trip time is bigger than current time 
						echo '<div style="background-color:white;color:black;margin:10px;padding:10px;border-radius:5px;font-size:15px;border:2px solid black;">
							TripTime:'.$row['TripTime'].' <br>From: '.$row['StartLocation'].'<br> To: '.$row['EndLocation'].' <br> Price: '.$_SESSION['Price'].'<br> TripID: '.$row['TripID'].'<br></div>';
					
					}
					}
				} else{
					echo  '<a href="javascript:windowname=window.open(\'view_trip_Admin.php\', \'windowname1\'); windowname.focus();void(0) ">There is no such that trip</a>';
				}
			} else {
				echo '<a href="javascript:windowname=window.open(\'view_trip_Admin.php\', \'windowname1\'); windowname.focus();void(0) ">There is no such that trip</a>';
}
}
mysqli_close($connection);
?>
	

	