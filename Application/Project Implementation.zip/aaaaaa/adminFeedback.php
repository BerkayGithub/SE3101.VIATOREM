
<?php 
error_reporting(0);
session_start();

// make sure user is logged in
if (!isset($_SESSION['email'])) {
    $loginError = "You are not logged in.";
    include("loginpage.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="viatorem.css">
<h2 style="color:blue;text-align:center;">Admin Homepage</center></h2>

</head>
<body>
<br><br><br><br><br>
<div class="preference">
    <label>Welcome John to the admin panel.</label>
    <br><br><br>
    
</div>
<ul>
  <li><a href="addtrip.php">Add Trip</a></li>
  <li><a href="canceltrip.php">Cancel Trip</a></li>
  <li><a href="addcampaign.php">Add/Remove Campaign</a></li>
  <li><a href="admincancelticket.php">Cancel Ticket</a></li>
  <li><a href="view_trip_Admin.php">View Trip</a></li>
  <li><a href="adminFeedback.php">FeedBack-Reject/Approve</a></li>
  <li><a href="logout.php">Log out</a></li>
</ul>
<?php 

include("connection.php");

$query = mysqli_query($connection, "SELECT * FROM FeedBack WHERE isApproved='0'");

if($query){
	echo "<h2>Feedback waiting for approval:</h2><br>";
	while($row = mysqli_fetch_array($query)){
		$query2 = mysqli_query($connection,"SELECT emaill FROM users WHERE UserID=".$row['UserID']);
		while($row2 = mysqli_fetch_array($query2)){
			echo '<div style="border-style:solid; border-width:1px;"><p>FROM:'.$row2['emaill'].' <br> Comment: '.$row['Content'].'</p><br>
			<form action="adminApproveFeedback.php" method="POST"><button type="submit" name="ApproveButton" value='.$row['FeedbackID'].'>Approve</button></form>
			<form action="adminRejectFeedback.php" method="POST"><button type="submit" name="RejectButton" value='.$row['FeedbackID'].'>Reject</button></form></div>';
		}
	}
}else {	
	echo "Couldn't issue database query";
	echo mysqli_error($connection);
}
?>
</body>
</html>