
<?php
session_start();
include("connection.php");

if($_POST){
	$feedback = $_POST['ApproveButton'];
	$query = mysqli_query($connection,"UPDATE Feedback SET isApproved = 1 WHERE FeedbackID=".$feedback);
	if($query){
		header('location: adminFeedback.php');
	}else{
		echo '<a href="adminFeedback.php">Olmadı</a>';
	}
}
?>