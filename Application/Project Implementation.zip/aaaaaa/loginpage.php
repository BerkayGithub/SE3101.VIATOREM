<?php  
session_start();
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
</head>
<style>
	body {font-family: Arial, Helvetica, sans-serif;}


.error {color: #FF0000;}
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 15px;
}
input[type=password]{
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
 font-size: 15px;
}
	input[type=email]{
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
 font-size: 15px;
}


#submit {
  background-color: black ;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  font-size:15px;
}

#submit:hover {
  opacity: 0.7;
}

#form1 {
  border-radius: 5px;
  display: inline-block;
  background-color: #f2f2f2;
  padding: 20px;
}

span.psw {
  float: right;
  padding-top: 16px;
}
	
</style>
<body>

	<center><h1>Login To The Viatorem</h1></center>
	
	<center>	
<form id="form1" name="form1" action="" method="post">
<table align="center">
    <tbody>
      <tr>
        <td>Email Address:</td>
        <td ><input type="email" name="email" id="email" placeholder="Enter your e-mail address" required ></td>
		  
      </tr>
      <tr>
        <td>Password:</td>
        <td><input type="password" name="password" id="password" placeholder="Enter your password" required></td>
		 
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="submit" id="submit" value="Login"></td>
      </tr>
    </tbody>
  </table>
	<span class="psw"> <a href="rewrite_email.php">Forgot password?</a> </span>
    <input type="checkbox" onclick="myFunction()">Show Password
</form><center><a href="registration.php"><br>
  REGISTRATION</a></center>
	</center>
	
	<script>
		function myFunction() {
			var x = document.getElementById("password");
			if (x.type === "password") {
				x.type = "text";
			} else {
				x.type = "password";
			}
		} 
	</script>
</body>
</html>

<?php
error_reporting(0);
session_start();

include('connection.php');


if($_POST){
	$email = $_POST["email"];
	$password = md5($_POST["password"]);
	$_SESSION['email'] = $_POST["email"];
	//email control
	/*if (empty($email)) {
		echo "<center>"."Email address is required.";
	} else {

    // check if e-mail address is well-formed
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			echo "<center>"."Invalid email address format.";
    }
  }*/

	
	
	$login= mysqli_query($connection,"SELECT * FROM Users WHERE emaill='$email' and pwd='$password'");
	//$sql = $connection ->query($login);
	
	
	if($login){
		$_SESSION['email'] = $email;
		if(mysqli_num_rows($login) == 0){
			echo '<a href="javascript:windowname=window.open(\'loginpage.php\', \'windowname1\'); windowname.focus();void(0) ">Your password or email is wrong!</a>';
		} else {
			while($row = mysqli_fetch_array($login)){
		//	$_SESSION["UserID"]= $row=["UserID"];
		
		
			$_SESSION["userType"]= $row["userType"];
			
		   if($_SESSION["userType"] == "admin"){
					$_SESSION["UserID"]= $row=["UserID"];
			header("location: adminHomepage.php");
			   
			} else if($_SESSION["userType"] == "officer"){
			   $_SESSION["UserID"]= $row=["UserID"];
					header("location: officerhomepage.php");
			   
				} else if($_SESSION["userType"] == "registered"){
			   $_SESSION["UserID"]= $row=["UserID"];
					header("location: Registered.php");
				} 
			}	
		}
	} else {
		echo '<a href="javascript:windowname=window.open(\'loginpage.php\', \'windowname1\'); windowname.focus();void(0) ">Ypur password or email is wrong!</a>';
	}
}
?>










