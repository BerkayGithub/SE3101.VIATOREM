<?php
error_reporting(0);
session_start();

include('connection.php');


if($_POST){
	$email = $_POST["email"];
	$password = md5($_POST["password"]);
	$_SESSION['email'] = $_POST["email"];
	//email control
	/*if (empty($email)) {
		echo "<center>"."Email address is required.";
	} else {

    // check if e-mail address is well-formed
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			echo "<center>"."Invalid email address format.";
    }
  }*/

	
	
	$login= mysqli_query($connection,"SELECT * FROM Users WHERE emaill='$email' and pwd='$password'");
	//$sql = $connection ->query($login);
	
	
	if($login){
		while($row = mysqli_fetch_array($login)){
		//	$_SESSION["UserID"]= $row=["UserID"];
		
		
			$_SESSION["userType"]= $row["userType"];
			
		   if($_SESSION["userType"] == "admin"){
					$_SESSION["UserID"]= $row=["UserID"];
			header("location: adminHomepage.php");
			   
			} else if($_SESSION["userType"] == "officer"){
			   $_SESSION["UserID"]= $row=["UserID"];
					header("location: officerhomepage.html");
			   
				} else if($_SESSION["userType"] == "registered"){
			   $_SESSION["UserID"]= $row=["UserID"];
					header("location: Registered.php");
				} else {
		echo '<a href="javascript:windowname=window.open(\'loginpage.php\', \'windowname1\'); windowname.focus();void(0) ">Ypur password or email is wrong!</a>';
	}

			
		}
	} else {
		echo '<a href="javascript:windowname=window.open(\'loginpage.php\', \'windowname1\'); windowname.focus();void(0) ">Ypur password or email is wrong!</a>';
	}
}
?>










