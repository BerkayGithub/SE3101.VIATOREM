<?php include("registrationpage.php");
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>REGISTRATION</title>
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}


.error {color: #FF0000;}
input[type=text] {
  width: 200%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 15px;
}
input[type=password]{
  width: 200%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
 font-size: 15px;
}

input[type=date] {
  width: 200%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 15px;
}
input[type=tel] {
  width: 200%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 15px;
}
input[type=email] {
  width: 200%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 15px;
}
#submit {
  background-color: black ;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  font-size:15px;
}

#submit:hover {
  opacity: 0.7;
}

#form1 {
  border-radius: 5px;
  display: inline-block;
  background-color: #f2f2f2;
  padding: 20px;
 border: 2px solid black;
	width: 50%;

	}

</style>
<body>
<center><h1>REGISTRATION</h1></center>
	<center>
<form id="form1" name="form1" action="registrationpage.php" method="post">
  <table  align="center">
    <tbody>
      <tr>
        <td >Name:</td>
        <td ><input type="text" name="name" id="name" required></td>
      </tr>
      <tr>
        <td>Surname:</td>
        <td><input type="text" name="surname" id="surname" required></td>
	  </tr>
	  <tr>
        <td >Email Adress:</td>
        <td ><input type="email" name="email" id="email" placeholder="Enter an email address in the correct form" required></td>
      </tr>
      <tr>
        <td >Password:</td>
        <td ><input type="password" name="password" id="password" required></td>
      </tr>
	  <tr>
        <td >Gender:</td>
        <td ><select name ="gender">
			<option value="F" name="F">Female</option>
			<option value="M" name="M">Male</option>
			</select></td>
      </tr>
	  <tr>
        <td >Cellphone Number:</td>
        <td ><input type="tel" name="phonenmb" id="phonenmb" placeholder="Format: 0123-436-5689"></td>
      </tr>

      <tr>
        <td >BirthDate:</td>
        <td ><input type="date" name="birthdate" id="birthdate"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="submit" id="submit" value="SIGN UP"></td>
      </tr>
    </tbody>
	  
  </table>
	<input  type="checkbox" onclick="myFunction()" >Show Password
	<h3>SECURITY QUESTION</h3>
	<h2>Select a question and answer it</h2>
	<select name="questions"  style="width:330px; height: 25px" required>
		<option value="1" name="question1">Your favorite fruit</option>
		<option value="2" name="question2">Name of your favorite teacher in high school</option>
		<option value="3" name="question3">Second letter of your mother's maiden name</option>
		<option value="4" name="question4">Your favorite vegatables</option>
		<option value="5" name="question5">Your favorite color</option>
	</select>
	<br>
	<textarea name="answer" rows="1" cols="40" placeholder="Your answer"></textarea>
</form>
		</center>
	<center>
	  <p>&nbsp;</p>
	  <p><a href="loginpage.php">Have Already An Account?</a></p>
	</center>
	
	<script>
		function myFunction() {
			var x = document.getElementById("password");
			if (x.type === "password") {
				x.type = "text";
			} else {
				x.type = "password";
			}
		} 
	</script>
</body>
</html>
<?php
error_reporting(0);
session_start();


include('connection.php');

if($connection -> connect_error){
	die("Connection failed: " .$connection -> connect_error);
}

if($_POST){
	$name = $_POST['name'];
    $surname = $_POST['surname'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $gender=$_POST['gender'];
    $phonenmb=$_POST['phonenmb'];
    $birthdate=$_POST['birthdate'];
	
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      echo "Invalid email format";
    }
	
	$password= md5($password);
	$question=$_POST['questions'];
	$answer= $_POST['answer'];
	
	if(isset($question) && isset($answer)){
	
			echo "Secret question and its answer are required!!!";
	}
	if($question == 1){
		$registration = "INSERT INTO users(emaill,pwd,name,surname,userType,birtDate,gender,phoneNumber, Question, AnswerToQuestion) 
                         VALUES ('$email','$password','$name','$surname','registered','$birthdate','$gender','$phonenmb', 'question1', '$answer')";
	} else if($question == 2){
		$registration = "INSERT INTO users(emaill,pwd,name,surname,userType,birtDate,gender,phoneNumber, Question, AnswerToQuestion) 
                         VALUES ('$email','$password','$name','$surname','registered','$birthdate','$gender','$phonenmb', 'question2', '$answer')";
	} else if($question == 3){
		$registration = "INSERT INTO users(emaill,pwd,name,surname,userType,birtDate,gender,phoneNumber, Question, AnswerToQuestion) 
                         VALUES ('$email','$password','$name','$surname','registered','$birthdate','$gender','$phonenmb', 'question3', '$answer')";
	} else if($question == 4){
		$registration = "INSERT INTO users(emaill,pwd,name,surname,userType,birtDate,gender,phoneNumber, Question, AnswerToQuestion) 
                         VALUES ('$email','$password','$name','$surname','registered','$birthdate','$gender','$phonenmb', 'question4', '$answer')";
	} else if( $question == 5){
		$registration = "INSERT INTO users(emaill,pwd,name,surname,userType,birtDate,gender,phoneNumber, Question, AnswerToQuestion) 
                         VALUES ('$email','$password','$name','$surname','registered','$birthdate','$gender','$phonenmb', 'question5', '$answer')";
	} else {
		echo "Somethings go wrong" ;
	}
	

	$result=mysqli_query($connection,$registration);
   if($result){
	   header("location: loginpage.php");
   } else {
	   echo  '<a href="javascript:windowname=window.open(\'registration.php\', \'windowname1\'); windowname.focus();void(0) ">There is something wrong. Please try again</a>';
   }
	
}

?>
