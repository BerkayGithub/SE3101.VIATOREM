<?php 

session_start();
if(!isset($_SESSION['email'])) {
	$loginError="You are not logged in";
	include("loginpage.php");
	exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="viatorem.css">
<meta charset="utf-8">
<title></title>
</head>

<body>

<br>
<br>
<br>
<br>
	<center>
<form id="form1" name="cancel_trip" action="" method="post">
	<table>
		<tbody>
      <tr>
        <td>TRIP ID:</td>
        <td ><input type="text" name="TripID" id="TripID" placeholder="Enter TripID number of trip" required ></td>
		  
      </tr>
			
	  <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="admincanceltrip" id="submit" value="Cancel Trip"></td>
      </tr>
	
	
	</table>
	
	</form>
</center>


	
	
<?php
error_reporting(0);
session_start();


include('connection.php');


if($connection -> connect_error){
	die("Connection failed: " .$connection -> connect_error);
}

if($_POST){
			$TripID = $_POST['TripID'];
			


		$query= mysqli_query($connection,"SELECT * FROM trip WHERE TripID =$TripID" );
		
		if($query){
	
			while($row= mysqli_fetch_array($query)){

				//$pnr_nmb = $row['PNR'];
				if($row['isCancelled'] == 0){
					$admincanceltrip= "UPDATE trip 
					               SET isCancelled='1' WHERE TripID = '".$_POST['TripID']."'";
					$result=mysqli_query($connection,$admincanceltrip);
				} if($result){
					echo 'Trip successfully cancelled!';
				} else{
					echo ' Ticket was not cancelled!It should be aldready cancelled or wrong trip id entry!';
				}
					
			}
		} else {
			echo 'There is something wrong!';
		}
				
	}


		
	


?>
</body>
</html>
